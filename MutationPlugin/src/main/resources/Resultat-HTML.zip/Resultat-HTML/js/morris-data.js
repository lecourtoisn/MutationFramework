$(function() {

    Morris.Donut({
      element: 'morris-donut-chart',
      data: [
        {value: 0.0, label: 'Mutants tues'},
        {value: 0.0, label: 'Mutants morts nes'},
        {value: 0.0, label: 'Mutants non tues'},
      ],
      formatter: function (x) { return x + "%"}
    }).on('click', function(i, row){
      console.log(i, row);
    });

    Morris.Bar({
        element: 'morris-bar-chart',
        data: [
        /*{
            nom: 'nom',
            nb: 100,
        }*/ 
        //debut datas
        ],
        xkey: 'nom',
        ykeys: ['nb'],
        labels: ['Nombre du mutant tués'],
        hideHover: 'auto',
        resize: true
    });

});
